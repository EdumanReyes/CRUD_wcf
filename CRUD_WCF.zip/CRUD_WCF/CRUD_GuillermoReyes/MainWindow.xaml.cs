﻿using CRUD_GuillermoReyes.CrudService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CRUD_GuillermoReyes
{
    /// <summary>
    /// Lógica de interacción para MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private List<Person> personas;
        CrudService.Service1Client service;
        private bool editarClick = false;
        public MainWindow()
        {
            InitializeComponent();
            personas = new List<Person>();
            service = new CrudService.Service1Client();
           

            // Columnas del DataGrid
            DataGridTextColumn column1 = new DataGridTextColumn();
            column1.Header = "Id";
            column1.Binding = new System.Windows.Data.Binding("Id");
            column1.Width = 20;

            DataGridTextColumn column2 = new DataGridTextColumn();
            column2.Header = "Edad";
            column2.Binding = new System.Windows.Data.Binding("Edad");
            column2.Width = 40;

            DataGridTextColumn column3 = new DataGridTextColumn();
            column3.Header = "Nombre";
            column3.Binding = new System.Windows.Data.Binding("Nombre");
            column3.Width = 250;

            DataGridTextColumn column4 = new DataGridTextColumn();
            column4.Header = "Email";
            column4.Binding = new System.Windows.Data.Binding("Email");
            column4.Width = 235;

            dgTabla.Columns.Add(column1);
            dgTabla.Columns.Add(column2);
            dgTabla.Columns.Add(column3);
            dgTabla.Columns.Add(column4);



            this.GetPersons();
        }


        private void GetPersons()
        {
            try
            {
                CrudService.Customer[] customers;
                customers = service.GetAllCustomer();

                dgTabla.ItemsSource = customers;
            }
            catch (Exception ex) { }
        }


        private void Guardar(object sender, RoutedEventArgs e)
        {

            if (string.IsNullOrEmpty(txtEdad.Text) ||
                string.IsNullOrEmpty(txtNombre.Text) ||
                string.IsNullOrEmpty(txtCorreo.Text))
            {
                MessageBox.Show("Para guardar por favor complete todos los campos");
                return;
            }
            else
            {
                
                //Extracción de texto de textboxes
                if (!int.TryParse(txtEdad.Text, out int edad)) {
                    MessageBox.Show("Por favor, ingrese una edad válida.");
                    return;
                }
                string nombre = txtNombre.Text;
                string correo = txtCorreo.Text;
           
               /* Person nuevaPersona = new Person
                {
                    Id = id,
                    Edad = edad,
                    Nombre = nombre,
                    Correo = correo
                };*/

                CrudService.Customer customer = new CrudService.Customer();
                customer.Nombre = nombre;
                customer.Edad = edad;
                customer.Email = correo;
                // Agregar la nueva persona
                //personas.Add(nuevaPersona);

                if (editarClick)
                {
                    customer.Id = Int16.Parse(txtId.Text);
                    service.UpdateCustomer(customer);
                }
                else
                {
                    service.InsertCustomer(customer);
                }
                dgTabla.ItemsSource = null;
                this.GetPersons();

                txtId.Text = "";
                txtEdad.Text = "";
                txtNombre.Text = "";
                txtCorreo.Text = "";
            }
        }

        private void Eliminar(object sender, RoutedEventArgs e)
        {
            //Person personaSeleccionada = dgTabla.SelectedItem as Person;
            Customer personaSeleccionada = dgTabla.SelectedItem as Customer;
            CrudService.Customer[] customers;
            customers = service.GetAllCustomer();

            if (customers.Length == 0)
            {
                MessageBox.Show("No hay personas registradas,por favor registre una primero.");
                return;
            }
            else
            {
                if (personaSeleccionada == null)
                {
                    MessageBox.Show("Seleccione una persona para eliminar.");
                    return;
                }
            }

            // personas.Remove(personaSeleccionada);
            service.DeleteCustomer(personaSeleccionada.Id);
            dgTabla.ItemsSource = null;
            this.GetPersons();
        }

        private void Nuevo(object sender, RoutedEventArgs e)
        {
            // Limpiar los TextBox
            txtId.Text = "";
            txtEdad.Text = "";
            txtNombre.Text = "";
            txtCorreo.Text = "";

            btnNuevo.IsEnabled = false;
        }

        private void Editar(object sender, MouseButtonEventArgs e)
        {
           // Person personaSeleccionada = dgTabla.SelectedItem as Person;
            Customer personaSeleccionada = dgTabla.SelectedItem as Customer;
            if (personaSeleccionada != null)
            {
                // Valores de la persona a los TextBox
                txtId.Text = personaSeleccionada.Id.ToString();
                txtEdad.Text = personaSeleccionada.Edad.ToString();
                txtNombre.Text = personaSeleccionada.Nombre;
                txtCorreo.Text = personaSeleccionada.Email;
                editarClick = true;
                btnNuevo.IsEnabled = true;

            }
        }
    }
}
